import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Type interface for our Products
interface Product {
  id: string;
  title: string;
  category: string;
  price: number;
  rating: number;
  image: string;
  description: string;
  specs: string[];
  features: string[];
}

// Curated list of premium minimalist workspace and productivity items
const PRODUCTS: Product[] = [
  {
    id: "prod-1",
    title: "NuPhy Air75 V2 Keyboard",
    category: "Keyboards & Typing",
    price: 139,
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1595225476474-87563907a212?auto=format&fit=crop&q=80&w=600",
    description: "An ultra-thin, low-profile mechanical keyboard designed for compact portability and responsive tactile feedback. Perfect for aesthetic workstations.",
    specs: ["75% Layout", "Low-Profile Gateron Switches", "Tri-mode wireless (2.4G/BT5.0/Wired)", "QMK/VIA Support"],
    features: ["Aluminum top case", "PBT double-shot keycaps", "Hot-swappable switches", "Slim 16mm profile"]
  },
  {
    id: "prod-2",
    title: "Merino Wool Desk Mat",
    category: "Desk & Organization",
    price: 79,
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1616440347437-b1c73416efc2?auto=format&fit=crop&q=80&w=600",
    description: "Crafted from 100% genuine merino wool, this premium desk mat adds comfort, texture, and warmth to your minimal desk layout.",
    specs: ["800mm x 300mm", "4mm Thickness", "Natural wool felt", "Anti-slip cork backing"],
    features: ["Noise dampening", "Stitch-reinforced design", "Eco-friendly materials", "Water-resistant coating"]
  },
  {
    id: "prod-3",
    title: "Sennheiser HD 490 Pro",
    category: "Audio & Acoustics",
    price: 399,
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&q=80&w=600",
    description: "Open-back reference studio headphones engineered for precise soundstage representation, rich bass dynamics, and ultimate mix clarity.",
    specs: ["Open-back over-ear", "Frequency range: 5Hz - 36kHz", "Impedance: 130 Ohms", "Weight: 260g"],
    features: ["Ergonomic velvet ear pads", "Pro-mixing sound voicing", "Detachable single-sided cable", "Excellent thermal regulation"]
  },
  {
    id: "prod-4",
    title: "ScreenBar Halo Monitor Light",
    category: "Lighting & Ambiance",
    price: 189,
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1507646227500-4d389b0012be?auto=format&fit=crop&q=80&w=600",
    description: "Intelligent monitor-mounted light bar with customizable ambient backlighting, localized auto-dimming sensor, and wireless rotary controller.",
    specs: ["500 Lux center brightness", "Color Temp: 2700K - 6500K", "USB-powered", "Asymmetric optical path"],
    features: ["No screen glare", "Wireless desk dial preset", "Counter-weight clip design", "Dynamic background halo"]
  },
  {
    id: "prod-5",
    title: "Anker Prime 240W GaN Station",
    category: "Power & Charging",
    price: 169,
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1622445262465-2481c4574875?auto=format&fit=crop&q=80&w=600",
    description: "Multi-port tabletop charger leveraging fast GaN technology to output up to 240W simultaneously. Powers notebooks, phones, and peripherals elegantly.",
    specs: ["3 USB-C / 1 USB-A", "GaNPrime Tech", "Real-time power monitoring", "Ultra-compact profile"],
    features: ["ActiveShield 2.0 heating control", "Elegantly stands vertically", "Smart power allocation", "Heavy duty desktop chord"]
  },
  {
    id: "prod-6",
    title: "Minimalist Wooden Desk Shelf",
    category: "Desk & Organization",
    price: 149,
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=600",
    description: "Handcrafted solid walnut monitor stand and organizer to raise screens to eye level while optimizing desk shelf spacing.",
    specs: ["115cm Length x 22cm Width", "Grade-A solid walnut", "Anodized aluminum legs", "Max weight: 50kg"],
    features: ["Ergonomic screen elevation", "Integrated cable routing rails", "Felt bottom desk protection", "Matte satin lacquer finish"]
  },
  {
    id: "prod-7",
    title: "HHKB Professional Hybrid Type-S",
    category: "Keyboards & Typing",
    price: 329,
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1618384887929-16ec33fab9ef?auto=format&fit=crop&q=80&w=600",
    description: "The Holy Grail of programmers' keyboards. Features elite Topre electrostatic capacitive switches with silent actuation and a professional layout.",
    specs: ["60% HHKB layout", "Silent Topre Keys", "Bluetooth Multipairing + Type-C", "Custom PBT sub-dyed keycaps"],
    features: ["Electrostatic capacitance key switches", "Unrivaled tactical feel", "DIP-switch layout modifiers", "Ultra-long battery duty"]
  },
  {
    id: "prod-8",
    title: "Teenage Engineering OB-4 Speaker",
    category: "Audio & Acoustics",
    price: 649,
    rating: 4.6,
    image: "https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&q=80&w=600",
    description: "The magic radio with 4-element high-fidelity sound, real-time audio rolling buffer recording (the loop machine), and a highly eccentric handle.",
    specs: ["38Hz - 20kHz response", "Two 4-inch bass drivers", "Two neodymium tweeters", "50W ultra efficient class-D amp"],
    features: ["Infinite soundtrack loop generator", "Breathtaking natural acoustics", "Motorized volume slider widget", "Real-time 2-hour radio buffer"]
  },
  {
    id: "prod-9",
    title: "Nomad Base One Max Dock",
    category: "Power & Charging",
    price: 149,
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&q=80&w=600",
    description: "Premium glass and solid metal MagSafe charger featuring weighted premium stability, delivering true 15W high-speed charging to iPhone and Apple Watch.",
    specs: ["15W MagSafe output", "Apple Watch charger integrated", "Solid zinc chassis", "Weight: 900g"],
    features: ["Beautiful tempered glass top", "Anti-skid weighted platform", "Officially Certified MagSafe", "Elevates device aesthetic"]
  },
  {
    id: "prod-10",
    title: "Govee Aura Smart Table Lamp",
    category: "Lighting & Ambiance",
    price: 69,
    rating: 4.5,
    image: "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&q=80&w=600",
    description: "Seamless cylindrical night light lamp with individual RGBIC gradient controls, smart home integrations, and rich audio sync music visual modes.",
    specs: ["350 Lumens output", "RGBIC WW led", "Wi-Fi + Bluetooth", "Height: 20cm"],
    features: ["Intelligent DIY light templates", "Smart speaker control", "Relaxation noise machine", "Capacitive top tap button"]
  }
];

// Lazy-initialize Gemini API Client
let geminiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!geminiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
      geminiClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
      console.log("Gemini Client initialized successfully on server.");
    } else {
      console.warn("GEMINI_API_KEY environment variable is missing or placeholder. Running fallback local recommendations.");
    }
  }
  return geminiClient;
}

// REST route to retrieve products database
app.get("/api/products", (req, res) => {
  const query = (req.query.q || "").toString().toLowerCase();
  const category = (req.query.category || "").toString().toLowerCase();

  let filtered = PRODUCTS;
  if (query) {
    filtered = filtered.filter(p => 
      p.title.toLowerCase().includes(query) || 
      p.description.toLowerCase().includes(query) ||
      p.category.toLowerCase().includes(query) ||
      p.specs.some(s => s.toLowerCase().includes(query)) ||
      p.features.some(f => f.toLowerCase().includes(query))
    );
  }
  if (category && category !== "all") {
    filtered = filtered.filter(p => p.category.toLowerCase() === category);
  }
  res.json({ products: filtered });
});

// Full-blown server-side recommendation & intent analysis endpoint
app.post("/api/recommendations", async (req, res) => {
  const { query, activeCategory } = req.body;
  const userQuery = query ? query.trim() : "";
  const category = activeCategory || "all";

  // Check if Gemini API is configured
  const ai = getGeminiClient();

  // Standard engineering recommendation logic structure
  interface AIRecommendationResponse {
    recommendationReason: string;
    suggestedCategory: string;
    smartComplementary: Array<{
      title: string;
      category: string;
      estimatedPrice: number;
      description: string;
      specs: string[];
      matchReason: string;
    }>;
    smartTags: string[];
    matchingProductIds: string[]; // Ideal ranking ids
  }

  // Define static fallback data depending on queries to ensure the experience is incredible even offline
  const generateLocalRecommendation = (userQ: string): AIRecommendationResponse => {
    const lowerQ = userQ.toLowerCase();
    
    if (lowerQ.includes("keyboard") || lowerQ.includes("type") || lowerQ.includes("switch") || lowerQ.includes("nuphi") || lowerQ.includes("hhkb")) {
      return {
        recommendationReason: "We noticed you're searching for premium input devices. Mechanical typing enthusiasts value high-grade tactile comfort and unique electrostatic switches like Topre or custom low-profile stabilizers that optimize keyboard fatigue.",
        suggestedCategory: "Keyboards & Typing",
        smartComplementary: [
          {
            title: "Krytox GPL 205g0 Switch Lube",
            category: "Keyboard Accessories",
            estimatedPrice: 15,
            description: "High-performance fluorinated mechanical keyboard lube designed to refine switch acoustics, reduce spring ping, and stabilize stem travel.",
            specs: ["5g Vial", "Grade 0 consistency", "Supports linear and stabilizer lubing"],
            matchReason: "Perfect addition to customized mechanical keyboards like NuPhy or HHKB to make keystrokes completely smooth and creamy."
          }
        ],
        smartTags: ["Topre Silent", "PBT Low Profile", "QMK Programmable", "Mechanical Switches"],
        matchingProductIds: ["prod-1", "prod-7"]
      };
    }

    if (lowerQ.includes("music") || lowerQ.includes("sound") || lowerQ.includes("headphone") || lowerQ.includes("audio") || lowerQ.includes("speaker") || lowerQ.includes("sennheiser")) {
      return {
        recommendationReason: "It looks like acoustics and studio sounds are your priority. Elevating audio with open-back acoustics or active spatial stereo drivers creates an immersive audio landscape, suitable for deep workflow focus or precision editing.",
        suggestedCategory: "Audio & Acoustics",
        smartComplementary: [
          {
            title: "Audiophile DAC & Headphone AMP Node",
            category: "Audio Equipment",
            estimatedPrice: 129,
            description: "Hi-Res USB digital-to-analog converter that delivers crisp, uncompressed, studio-grade signal output directly to professional high-impedance headphones.",
            specs: ["Dual ESS Sabre Chips", "Supports 32-bit/384kHz PCM", "3.5mm and 4.4mm balanced output"],
            matchReason: "Designed to easily drive the 130-Ohm Sennheiser HD 490 Pro headphones with uncompromised sound detail."
          }
        ],
        smartTags: ["High Impedance", "Audiophile Stage", "Acoustic Tuning", "Bluetooth High-Def"],
        matchingProductIds: ["prod-3", "prod-8"]
      };
    }

    if (lowerQ.includes("cable") || lowerQ.includes("power") || lowerQ.includes("charge") || lowerQ.includes("battery") || lowerQ.includes("anker") || lowerQ.includes("nomad")) {
      return {
        recommendationReason: "You're streamlining your power infrastructure. Efficient GaN chargers and weighted wireless stands eliminate cable clutter and protect expensive workstation accessories from heat spikes.",
        suggestedCategory: "Power & Charging",
        smartComplementary: [
          {
            title: "Nomad Kevlar-braid Type-C Cable",
            category: "Power Cables",
            estimatedPrice: 35,
            description: "Bulletproof 1.5m carbon fiber weave cable supporting 100W Power Delivery, designed to never fray or damage desktop docking setups.",
            specs: ["Kevlar-reinforced sleeve", "100W PD charging speed", "Subtle matte alloy connectors"],
            matchReason: "Pairs beautifully with the heavy-duty Anker Prime charger for a unified visual and power desk profile."
          }
        ],
        smartTags: ["GaN Fast Charge", "Heavy Weighted", "Apple Certified", "Power Delivery 3.0"],
        matchingProductIds: ["prod-5", "prod-9"]
      };
    }

    // Default general layout/workspace setting recommendation
    return {
      recommendationReason: "Analyzing workspace layout preferences... You seem to be curating an exquisite combination of functionality and minimalistic aesthetics. Clean workspace ergonomics improve cognitive clarity, incorporating tactile textures (cork, wool) paired with smart indirect lighting.",
      suggestedCategory: "Desk & Organization",
      smartComplementary: [
        {
          title: "Oak Precision Desk Tray",
          category: "Desk & Organization",
          estimatedPrice: 45,
          description: "Solid oak sorting vessel with machined grooves to store pens, keys, flash drives, and adapters cleanly directly below your monitor stand.",
          specs: ["Solid Oak Wood", "CNC-machined layout", "Microfiber protective feet"],
          matchReason: "Matches your Minimalist Wooden Desk Shelf to unify wood accents across your aesthetic workspace."
        }
      ],
      smartTags: ["Studio Aesthetics", "Natural Wool Felt", "Asymmetric Optics", "Wireless Desk Dials"],
      matchingProductIds: ["prod-2", "prod-6", "prod-4"]
    };
  };

  // If no API key, return the quick local rule-based system
  if (!ai) {
    const localRec = generateLocalRecommendation(userQuery);
    return res.json(localRec);
  }

  try {
    // Inject system instructions and structured schemas using current Type enum for Type Safety
    const promptMessage = `
    Analyze the user's workspace search intent:
    Query: "${userQuery}"
    Active Workspace Filter: "${category}"

    Available Products reference list in our workspace stock:
    ${JSON.stringify(PRODUCTS.map(p => ({ id: p.id, title: p.title, category: p.category, description: p.description })))}

    Please perform a search engine recommendation analysis. Provide:
    1. recommendationReason: (A beautifully written human-centric paragraph in an Apple-inspired minimal professional voice, explaining how products on this topic elevate productivity, styling, and comfort. Keep it inspiring. Maximum 3 sentences).
    2. suggestedCategory: The single best category out of ["Keyboards & Typing", "Desk & Organization", "Audio & Acoustics", "Lighting & Ambiance", "Power & Charging"] that fits this intent.
    3. smartComplementary: Exactly one virtual companion accessory product NOT in the product list that would complete the user's dream desk setup for this query. Include its title, category, estimatedPrice, description, specs (array of strings), and matchReason (explain how it complements the products in our matching list).
    4. smartTags: 3 or 4 professional technical specifications or tag filter chips (e.g. "Mechanical Switches", "High Impedance", "Organic Cork", "GaN Charging Node").
    5. matchingProductIds: Choose the ids of the 2 or 3 products from our list that match this search target the closest (in order of priority). Refer strictly to: ${JSON.stringify(PRODUCTS.map(p=>p.id))}.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: promptMessage,
      config: {
        systemInstruction: "You are a professional workspace design consultant, technical curator, and expert recommendation engine systems architect. Your goal is to map the user's queries to incredibly precise recommendations matching Apple's minimal aesthetic. Provide strictly compliant JSON.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["recommendationReason", "suggestedCategory", "smartComplementary", "smartTags", "matchingProductIds"],
          properties: {
            recommendationReason: {
              type: Type.STRING,
              description: "Elegant brief expert comment on the search theme and productivity elevation."
            },
            suggestedCategory: {
              type: Type.STRING,
              description: "Single category fit."
            },
            smartComplementary: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                required: ["title", "category", "estimatedPrice", "description", "specs", "matchReason"],
                properties: {
                  title: { type: Type.STRING },
                  category: { type: Type.STRING },
                  estimatedPrice: { type: Type.NUMBER },
                  description: { type: Type.STRING },
                  specs: { type: Type.ARRAY, items: { type: Type.STRING } },
                  matchReason: { type: Type.STRING }
                }
              }
            },
            smartTags: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            matchingProductIds: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          }
        }
      }
    });

    const parsedData = JSON.parse(response.text?.trim() || "{}");
    res.json(parsedData);
  } catch (error: any) {
    console.error("Gemini Content Generation failed, running local recommender:", error);
    // Graceful fallback to avoid crash
    const localRec = generateLocalRecommendation(userQuery);
    res.json(localRec);
  }
});

// Configure Vite or Static Assets path depending on environment
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    // Instantiate Vite in middlewareMode for lightning-fast HMR-less updates & live routing
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite dev middleware mounted successfully onto Express server.");
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Statically serving optimized client-side React bundle in production.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Product Recommendation engine running on: http://localhost:${PORT}`);
  });
}

startServer();
