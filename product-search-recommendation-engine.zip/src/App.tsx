import { useState, useEffect } from "react";
import { AnimatePresence } from "motion/react";

import { Navigation } from "./components/Navigation";
import { DashboardView } from "./components/DashboardView";
import { InventoryView } from "./components/InventoryView";
import { AnalyticsView } from "./components/AnalyticsView";
import { SettingsView } from "./components/SettingsView";
import { SyllabusInsights } from "./components/SyllabusInsights";

import { useDebounce } from "./hooks/useDebounce";
import { Product, AIRecommendation, SearchState } from "./types";

export default function App() {
  const [activeNav, setActiveNav] = useState("Dashboard");
  const [searchValue, setSearchValue] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>([]);
  
  // Sorting options
  const [sortBy, setSortBy] = useState<SearchState["sortBy"]>("relevance");

  // Recommendation engine state
  const [recommendation, setRecommendation] = useState<AIRecommendation | null>(null);
  const [isProductsLoading, setIsProductsLoading] = useState(true);
  const [isRecommendationLoading, setIsRecommendationLoading] = useState(true);

  // States for interactive sub-views (Inventory / Analytics / Settings)
  const [inventorySearch, setInventorySearch] = useState("");
  const [inventoryFilter, setInventoryFilter] = useState("All"); // All | Low Stock | Normal
  const [inventoryStock, setInventoryStock] = useState<Record<string, number>>({
    "prod-1": 14,
    "prod-2": 5,
    "prod-3": 2, // low stock
    "prod-4": 8,
    "prod-5": 22,
    "prod-6": 12,
    "prod-7": 3,  // low stock
    "prod-8": 1,  // low stock
    "prod-9": 19,
    "prod-10": 34
  });

  const [activeClusterNode, setActiveClusterNode] = useState("Audio & Acoustics");
  const [engineTemp, setEngineTemp] = useState(0.72);
  const [latentNodes, setLatentNodes] = useState(14204);
  const [simRunning, setSimRunning] = useState(true);
  const [debounceSetting, setDebounceSetting] = useState(350);
  
  // Custom event logs for settings tab
  const [systemLogs, setSystemLogs] = useState<string[]>([
    "[13:24:05] SECURE_HANDSHAKE: Initiated security handshake.",
    "[13:24:06] LATENT_GRID: Loaded 14,204 high-dimensional vector embeddings.",
    "[13:24:08] AI_ENGINE: Synced with Google Gemini-3.5-Flash.",
    "[14:15:32] CACHE_HIT: Resolved search index from local storage buffer."
  ]);

  // Debounce the user input using the dynamic latency parameter set in settings to prevent extra server hits
  const debouncedSearchQuery = useDebounce(searchValue, debounceSetting);

  // Fetch the stock products list based on active category & search query
  useEffect(() => {
    let ignore = false;
    setIsProductsLoading(true);

    const fetchProducts = async () => {
      try {
        const queryParam = encodeURIComponent(debouncedSearchQuery);
        const categoryParam = encodeURIComponent(activeCategory);
        const res = await fetch(`/api/products?q=${queryParam}&category=${categoryParam}`);
        const data = await res.json();
        
        if (!ignore) {
          setProducts(data.products || []);
          setIsProductsLoading(false);
        }
      } catch (err) {
        console.error("Failed to load products list:", err);
        if (!ignore) {
          setIsProductsLoading(false);
        }
      }
    };

    fetchProducts();
    return () => {
      ignore = true;
    };
  }, [debouncedSearchQuery, activeCategory]);

  // Fetch real-time AI Recommendations & thematic complements via Gemini server-side route
  useEffect(() => {
    let ignore = false;
    setIsRecommendationLoading(true);

    const fetchAIRecommendations = async () => {
      try {
        const response = await fetch("/api/recommendations", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            query: debouncedSearchQuery,
            activeCategory: activeCategory
          })
        });

        const data = await response.json();

        if (!ignore) {
          setRecommendation(data);
          setIsRecommendationLoading(false);
        }
      } catch (err) {
        console.error("AI Recommendation fetch failed:", err);
        if (!ignore) {
          setIsRecommendationLoading(false);
        }
      }
    };

    fetchAIRecommendations();
    return () => {
      ignore = true;
    };
  }, [debouncedSearchQuery, activeCategory]);

  // Clean clear callback
  const handleClearSearch = () => {
    setSearchValue("");
  };

  // Toggle products for deep comparative setups
  const handleToggleProductId = (id: string) => {
    if (selectedProductIds.includes(id)) {
      setSelectedProductIds(selectedProductIds.filter(item => item !== id));
    } else {
      setSelectedProductIds([...selectedProductIds, id]);
    }
  };

  const handleApplySmartTag = (tag: string) => {
    setSearchValue(tag);
  };

  // Apply visual sorting pure array mechanics to avoid state synchronization mutations
  const sortedProducts = [...products].sort((a, b) => {
    if (sortBy === "price_asc") return a.price - b.price;
    if (sortBy === "price_desc") return b.price - a.price;
    if (sortBy === "rating_desc") return b.rating - a.rating;
    
    // Default relevance sorting: prioritizes Gemini recommendation engine matches
    if (sortBy === "relevance" && recommendation?.matchingProductIds) {
      const aIndex = recommendation.matchingProductIds.indexOf(a.id);
      const bIndex = recommendation.matchingProductIds.indexOf(b.id);
      if (aIndex !== -1 && bIndex === -1) return -1;
      if (bIndex !== -1 && aIndex === -1) return 1;
      if (aIndex !== -1 && bIndex !== -1) return aIndex - bIndex;
    }
    return 0; // maintain original search alignment
  });

  return (
    <div className="min-h-screen bg-[#F5F5F7] pb-16 text-[#1D1D1F] font-sans antialiased selection:bg-orange-500/20" id="main-applet-wrapper">
      
      {/* Brand Navigation Header */}
      <Navigation activeNav={activeNav} setActiveNav={setActiveNav} />

      <AnimatePresence mode="wait">
        {activeNav === "Dashboard" && (
          <DashboardView
            searchValue={searchValue}
            setSearchValue={setSearchValue}
            activeCategory={activeCategory}
            setActiveCategory={setActiveCategory}
            products={products}
            selectedProductIds={selectedProductIds}
            handleToggleProductId={handleToggleProductId}
            sortBy={sortBy}
            setSortBy={setSortBy}
            recommendation={recommendation}
            isProductsLoading={isProductsLoading}
            isRecommendationLoading={isRecommendationLoading}
            debounceSetting={debounceSetting}
            latentNodes={latentNodes}
            simRunning={simRunning}
            handleClearSearch={handleClearSearch}
            handleApplySmartTag={handleApplySmartTag}
            sortedProducts={sortedProducts}
          />
        )}

        {/* INVENTORY VIEW */}
        {activeNav === "Inventory" && (
          <InventoryView
            inventorySearch={inventorySearch}
            setInventorySearch={setInventorySearch}
            inventoryFilter={inventoryFilter}
            setInventoryFilter={setInventoryFilter}
            inventoryStock={inventoryStock}
            setInventoryStock={setInventoryStock}
          />
        )}

        {/* ANALYTICS VIEW */}
        {activeNav === "Analytics" && (
          <AnalyticsView
            latentNodes={latentNodes}
            activeClusterNode={activeClusterNode}
            setActiveClusterNode={setActiveClusterNode}
            debounceSetting={debounceSetting}
            selectedProductIds={selectedProductIds}
            setActiveCategory={setActiveCategory}
            setActiveNav={setActiveNav}
          />
        )}

        {/* SETTINGS VIEW */}
        {activeNav === "Settings" && (
          <SettingsView
            engineTemp={engineTemp}
            setEngineTemp={setEngineTemp}
            latentNodes={latentNodes}
            setLatentNodes={setLatentNodes}
            debounceSetting={debounceSetting}
            setDebounceSetting={setDebounceSetting}
            simRunning={simRunning}
            setSimRunning={setSimRunning}
            systemLogs={systemLogs}
            setSystemLogs={setSystemLogs}
            setSelectedProductIds={setSelectedProductIds}
          />
        )}
      </AnimatePresence>

      {/* SYLLABUS ALIGNMENT MODULE: Highlights deep framework theories directly matching syllabus images */}
      <SyllabusInsights />

      {/* Creative Artistic Flair Footer */}
      <footer className="mt-20 px-6 md:px-12 py-8 flex flex-col md:flex-row justify-between items-center gap-4 border-t border-gray-200 text-[10px] font-semibold text-gray-400 uppercase tracking-widest bg-white select-none">
        <div>Product&amp;co Build: release-2024.11.02</div>
        <div className="flex space-x-6">
          <span className="text-black cursor-pointer hover:underline">Terms of Service</span>
          <span className="cursor-pointer hover:underline">Privacy Manifesto</span>
          <span className="cursor-pointer hover:underline">System Logs</span>
        </div>
      </footer>

    </div>
  );
}
