import { motion } from "motion/react";
import { Sparkles, Lightbulb } from "lucide-react";
import { formatINR } from "../modules/currency";
import { PRODUCTS } from "../modules/products";

interface AnalyticsViewProps {
  latentNodes: number;
  activeClusterNode: string;
  setActiveClusterNode: (node: string) => void;
  debounceSetting: number;
  selectedProductIds: string[];
  setActiveCategory: (cat: string) => void;
  setActiveNav: (nav: string) => void;
}

export function AnalyticsView({
  latentNodes,
  activeClusterNode,
  setActiveClusterNode,
  debounceSetting,
  selectedProductIds,
  setActiveCategory,
  setActiveNav
}: AnalyticsViewProps) {

  // Calculate aggregated value of items in target cart converted to Indian Rupees (₹)
  const totalUSD = selectedProductIds.reduce((sum, id) => {
    const item = PRODUCTS.find(p => p.id === id);
    return sum + (item ? item.price : 0);
  }, 0);

  return (
    <motion.div
      key="analytics-view"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -12 }}
      transition={{ duration: 0.3 }}
      className="max-w-7xl mx-auto px-4 md:px-8 mt-12 space-y-8 min-h-[500px]"
    >
      <div className="text-center md:text-left space-y-2">
        <span className="text-[10px] font-mono uppercase tracking-[0.25em] font-bold text-orange-600 bg-orange-50/70 border border-orange-100/50 px-3.5 py-1.5 rounded-full inline-block">
          METRICS EXPLORER
        </span>
        <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight">
          Latent Vector Analytics
        </h2>
        <p className="text-gray-400 text-xs md:text-sm max-w-2xl leading-relaxed">
          Deconstruct core search embedding spaces, examine active coordinate distances, and calculate configuration summaries dynamically based on Product&amp;co algorithms.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 select-none">
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-2">
          <div className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Active Latent Nodes</div>
          <div className="text-3xl font-extrabold text-gray-900 font-mono tracking-tight animate-pulse">
            {latentNodes.toLocaleString()}
          </div>
          <div className="text-[9.5px] text-emerald-600 font-bold flex items-center gap-1 uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            Embedded Vectors Online
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-2">
          <div className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Precision Threshold</div>
          <div className="text-3xl font-extrabold text-gray-900 font-mono tracking-tight">
            99.8%
          </div>
          <div className="text-[9.5px] text-orange-600 font-bold uppercase">
            Gemini-3.5 Core
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-2">
          <div className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Debounce Multiplier</div>
          <div className="text-3xl font-extrabold text-gray-900 font-mono tracking-tight">
            {debounceSetting}ms
          </div>
          <div className="text-[9.5px] text-gray-400 font-semibold uppercase">
            Processor Input Lag
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-2">
          <div className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Curated Setup Worth</div>
          <div className="text-3xl font-extrabold text-orange-600 font-mono tracking-tight animate-bounce">
            {formatINR(totalUSD)}
          </div>
          <div className="text-[9.5px] text-gray-400 font-semibold uppercase">
            Total Items Value (INR)
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8 bg-white p-6 border border-gray-150 rounded-3xl shadow-sm space-y-4">
          <div className="flex justify-between items-center pb-2 border-b border-gray-100 select-none">
            <h3 className="font-sans font-bold text-[11px] text-gray-900 uppercase tracking-widest">
              Semantics Node Cluster Space Map
            </h3>
            <span className="text-[9px] font-mono text-gray-400">Click coordinates to audit matching indexes</span>
          </div>

          <div className="relative bg-[#F5F5F7]/80 rounded-2xl h-80 flex items-center justify-center overflow-hidden border border-gray-200 border-dashed">
            <svg className="absolute inset-0 w-full h-full text-gray-200/50" fill="none">
              <defs>
                <pattern id="dotPatternMain" width="24" height="24" patternUnits="userSpaceOnUse">
                  <circle cx="2" cy="2" r="1" fill="currentColor" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#dotPatternMain)" />
              <circle cx="50%" cy="50%" r="50" stroke="currentColor" strokeWidth="1" strokeDasharray="3 3" />
              <circle cx="50%" cy="50%" r="100" stroke="currentColor" strokeWidth="1" strokeDasharray="3 3" />
              <circle cx="50%" cy="50%" r="140" stroke="currentColor" strokeWidth="1" strokeDasharray="3 3" />
            </svg>

            {[
              { name: "Keyboards & Typing", x: "32%", y: "45%", color: "bg-amber-500" },
              { name: "Desk & Organization", x: "65%", y: "30%", color: "bg-blue-500" },
              { name: "Audio & Acoustics", x: "50%", y: "55%", color: "bg-orange-500" },
              { name: "Lighting & Ambiance", x: "24%", y: "75%", color: "bg-rose-500" },
              { name: "Power & Charging", x: "78%", y: "65%", color: "bg-indigo-500" },
            ].map((node) => {
              const isFocused = activeClusterNode === node.name;
              return (
                <button
                  key={node.name}
                  onClick={() => setActiveClusterNode(node.name)}
                  style={{ left: node.x, top: node.y }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 group transition-all duration-300 cursor-pointer pointer-events-auto"
                >
                  <span className={`absolute -inset-4 rounded-full transition-all duration-300 ${
                    isFocused ? "bg-orange-500/10 scale-125 border border-orange-500/25 animate-ping" : "group-hover:bg-gray-500/5"
                  }`} />
                  <span className={`block w-4.5 h-4.5 rounded-full border-2 border-white shadow-md relative z-10 ${node.color} ${
                    isFocused ? "scale-125" : "group-hover:scale-110"
                  }`} />
                  <span className={`absolute top-6 left-1/2 -translate-x-1/2 whitespace-nowrap text-[9px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded shadow-sm bg-white text-gray-800 transition-colors ${
                    isFocused ? "bg-black text-white" : ""
                  }`}>
                    {node.name.split(" ")[0]}
                  </span>
                </button>
              );
            })}

            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-black text-white px-3.5 py-2 rounded-full flex items-center gap-1.5 shadow-xl relative select-none">
              <Sparkles className="h-3 w-3 text-orange-400 animate-pulse" />
              <span className="text-[10px] font-mono font-bold uppercase tracking-widest leading-none">Manifold Core</span>
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 bg-white p-6 border border-gray-150 rounded-3xl shadow-sm flex flex-col justify-between">
          <div className="space-y-4">
            <div className="pb-3 border-b border-gray-100 select-none">
              <h4 className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Focused Node Audit</h4>
              <h3 className="text-base font-extrabold text-gray-900 mt-1 select-text">{activeClusterNode}</h3>
            </div>

            <div className="space-y-3 font-sans text-xs select-none">
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-400">Euclidean Vector Match</span>
                <span className="font-mono text-gray-900 font-bold bg-[#F5F5F7] px-2 py-0.5 rounded text-[10.5px]">
                  {activeClusterNode === "Audio & Acoustics" ? "0.045 (Optimal)" :
                   activeClusterNode === "Keyboards & Typing" ? "0.112 (Coherent)" :
                   activeClusterNode === "Desk & Organization" ? "0.198 (Coherent)" :
                   activeClusterNode === "Power & Charging" ? "0.322 (Contextual)" :
                   "0.456 (Peripheral)"}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-400">Node Cluster Weight</span>
                <span className="font-mono text-gray-900 font-bold select-text">
                  {activeClusterNode === "Audio & Acoustics" ? "4.89 index units" :
                   activeClusterNode === "Keyboards & Typing" ? "3.24 index units" :
                   activeClusterNode === "Desk & Organization" ? "5.44 index units" :
                   activeClusterNode === "Power & Charging" ? "2.12 index units" :
                   "1.98 index units"}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-400">Represented Sub-Items</span>
                <span className="font-mono text-gray-900 font-bold select-text">2 Premium SKUs</span>
              </div>
            </div>

            <div className="bg-orange-50/30 border border-orange-100/40 p-4 rounded-2xl mt-2">
              <span className="text-[9px] font-mono font-bold uppercase tracking-wider text-orange-600 block">
                Model Preference Insights
              </span>
              <p className="text-xs text-gray-600 italic mt-1.5 leading-relaxed">
                {activeClusterNode === "Audio & Acoustics" && "Prioritize open-back acoustics with 130 ohms impedance to match quiet creative studio setups."}
                {activeClusterNode === "Keyboards & Typing" && "Map silent type electrostatic switches to avoid structural workspace typing interference noise."}
                {activeClusterNode === "Desk & Organization" && "Raise workflow screens to eye level and damp wood vibrations with natural cork & merino wool."}
                {activeClusterNode === "Lighting & Ambiance" && "Reduce monitor optical contrast glare with asymmetric lighting paths and USB power routing."}
                {activeClusterNode === "Power & Charging" && "Route tabletop power elegantly with compact triple-C GaN allocate boards up to 240W outputs."}
              </p>
            </div>
          </div>

          <button 
            onClick={() => {
              setActiveCategory(activeClusterNode);
              setActiveNav("Dashboard");
            }}
            className="w-full mt-6 bg-black hover:bg-orange-500 hover:text-white transition rounded-xl text-[10px] font-bold uppercase tracking-widest text-white py-3.5 block text-center cursor-pointer select-none"
          >
            Apply Filter &amp; Review Dashboard
          </button>
        </div>
      </div>
    </motion.div>
  );
}
