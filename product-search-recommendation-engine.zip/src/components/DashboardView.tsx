import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, 
  Lightbulb, 
  BookmarkPlus, 
  X, 
  ArrowRight
} from "lucide-react";

import { SearchBar } from "./SearchBar";
import { ProductGrid } from "./ProductGrid";
import { GridSkeleton } from "./LoadingSkeleton";
import { Product, AIRecommendation, SearchState } from "../types";
import { formatINR } from "../modules/currency";
import { PRODUCTS } from "../modules/products";

interface DashboardViewProps {
  searchValue: string;
  setSearchValue: (val: string) => void;
  activeCategory: string;
  setActiveCategory: (cat: string) => void;
  products: Product[];
  selectedProductIds: string[];
  handleToggleProductId: (id: string) => void;
  sortBy: SearchState["sortBy"];
  setSortBy: (sort: SearchState["sortBy"]) => void;
  recommendation: AIRecommendation | null;
  isProductsLoading: boolean;
  isRecommendationLoading: boolean;
  debounceSetting: number;
  latentNodes: number;
  simRunning: boolean;
  handleClearSearch: () => void;
  handleApplySmartTag: (tag: string) => void;
  sortedProducts: Product[];
}

export function DashboardView({
  searchValue,
  setSearchValue,
  activeCategory,
  setActiveCategory,
  selectedProductIds,
  handleToggleProductId,
  sortBy,
  setSortBy,
  recommendation,
  isProductsLoading,
  isRecommendationLoading,
  debounceSetting,
  latentNodes,
  simRunning,
  handleClearSearch,
  handleApplySmartTag,
  sortedProducts
}: DashboardViewProps) {

  const categories = [
    "all",
    "Keyboards & Typing",
    "Desk & Organization",
    "Audio & Acoustics",
    "Lighting & Ambiance",
    "Power & Charging"
  ];

  // Calculate aggregation sum in INR representation
  const aggregatedCostUSD = selectedProductIds.reduce((sum, id) => {
    const item = PRODUCTS.find(p => p.id === id);
    return sum + (item ? item.price : 0);
  }, 0);

  return (
    <motion.div
      key="dashboard-view"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -12 }}
      transition={{ duration: 0.3 }}
    >
      <header className="max-w-7xl mx-auto pt-12 pb-6 px-4 text-center" id="header-container">
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="space-y-3"
        >
          <span className="text-[10px] font-mono uppercase tracking-[0.25em] font-bold text-orange-600 bg-orange-50/70 border border-orange-100/50 px-3.5 py-1.5 rounded-full inline-block">
            INTELLIGENT SELECTION MODELS
          </span>
          <h1 className="font-sans font-extrabold text-3xl md:text-5xl text-gray-900 tracking-tight max-w-3xl mx-auto leading-tight">
            Product&amp;co Search Recommendation Engine
          </h1>
          <p className="font-sans text-gray-400 text-xs md:text-[14px] max-w-xl mx-auto leading-relaxed">
            Curate your aesthetic desk, studio, or power station. Our semantic intent engine leverages AI to analyze goals, re-sort workspace items, and model companion additions.
          </p>
        </motion.div>

        {/* Centralised Debounced Search Focal Point */}
        <div className="mt-10 mb-8" id="search-bar-widget-wrapper">
          <SearchBar 
            value={searchValue} 
            onChange={setSearchValue} 
            isLoading={isProductsLoading || isRecommendationLoading}
            onClear={handleClearSearch}
          />
        </div>

        {/* Category Filtration Track - Custom horizontal scroll styled like Apple devices */}
        <div className="flex items-center justify-center gap-1.5 overflow-x-auto py-2 no-scrollbar px-4" id="category-track-pills">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-full text-xs font-sans font-semibold transition cursor-pointer select-none border whitespace-nowrap ${
                activeCategory === cat
                  ? "bg-black border-black text-white shadow-sm"
                  : "bg-white border-transparent text-gray-500 hover:text-black hover:border-gray-200 shadow-sm"
              }`}
              id={`cat-button-${cat.replace(/\s+/g, '-').toLowerCase()}`}
            >
              {cat === "all" ? "All Categories" : cat}
            </button>
          ))}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 lg:grid-cols-12 gap-8 mt-6" id="dashboard-content-core">

        {/* LEFT COLUMN: Dynamic AI Assistant recommendation findings & companion highlights */}
        <section className="lg:col-span-4 space-y-6" id="ai-recommender-column">
          
          <div className="bg-white border border-gray-150/20 rounded-3xl p-6 shadow-sm relative overflow-hidden flex flex-col justify-between">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-orange-400/5 to-transparent rounded-full pointer-events-none" />

            <div>
              <div className="flex items-center gap-2.5 mb-5">
                <div className="p-2.5 bg-orange-50 text-orange-500 rounded-xl">
                  <Sparkles className="h-4.5 w-4.5 stroke-[2]" />
                </div>
                <div>
                  <h2 className="font-sans font-bold text-[12px] text-gray-900 uppercase tracking-widest leading-none">
                    Real-time AI Matchmaker
                  </h2>
                  <span className="text-[9px] font-mono text-gray-400 block mt-1">Contextual Intent Analysis</span>
                </div>
              </div>

              <AnimatePresence mode="wait">
                {isRecommendationLoading ? (
                  <motion.div
                    key="rec-loading"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="space-y-4"
                  >
                    <div className="h-3 w-1/3 bg-gray-150/40 rounded animate-pulse" />
                    <div className="space-y-2">
                      <div className="h-3.5 bg-gray-150/20 rounded animate-pulse" />
                      <div className="h-3.5 bg-gray-150/20 rounded animate-pulse" />
                      <div className="h-3.5 w-5/6 bg-gray-150/20 rounded animate-pulse" />
                    </div>
                    <div className="h-8 bg-gray-150/20 rounded-xl animate-pulse mt-4" />
                  </motion.div>
                ) : (
                  <motion.div
                    key="rec-loaded"
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -6 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-4 font-sans"
                  >
                    {/* Persona Insight Comment */}
                    <div className="bg-[#F5F5F7]/80 border border-transparent p-4 rounded-2xl">
                      <p className="text-xs text-gray-600 leading-relaxed italic">
                        "{recommendation?.recommendationReason}"
                      </p>
                    </div>

                    {/* Highly Smart Dynamic Complement Segment */}
                    {recommendation?.smartComplementary && recommendation.smartComplementary.length > 0 && (
                      <div className="pt-2">
                        <div className="flex items-center gap-1.5 text-xs font-semibold text-gray-500 uppercase tracking-widest mb-3">
                          <Lightbulb className="h-3.5 w-3.5 text-amber-500 stroke-[2.5]" />
                          <span>Perfect Companion Recommendation</span>
                        </div>

                        {recommendation.smartComplementary.map((comp, idx) => (
                          <div 
                            key={idx}
                            className="bg-orange-50/20 border border-orange-100/40 p-4 rounded-2xl shadow-sm space-y-2.5"
                            id={`smart-companion-${idx}`}
                          >
                            <div className="flex items-start justify-between">
                              <div>
                                <span className="text-[9px] font-bold text-orange-500 uppercase tracking-wider block">
                                  {comp.category}
                                </span>
                                <h3 className="font-semibold text-gray-900 text-[13px] leading-tight mt-0.5 animate-pulse">
                                  {comp.title}
                                </h3>
                              </div>
                              <span className="px-2 py-0.5 bg-white text-[11px] font-mono font-semibold text-gray-700 border border-orange-100 rounded">
                                ~{formatINR(comp.estimatedPrice)}
                              </span>
                            </div>

                            <p className="text-[11.5px] text-gray-500 leading-relaxed">
                              {comp.description}
                            </p>

                            <div className="text-[10px] text-orange-700/80 leading-relaxed pt-1 flex items-start gap-1">
                              <span className="shrink-0 mt-0.5">✦</span>
                              <span><strong>Reason:</strong> {comp.matchReason}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Dynamically Generated Smart specification chips */}
                    {recommendation?.smartTags && recommendation.smartTags.length > 0 && (
                      <div className="space-y-2">
                        <span className="text-[9px] uppercase font-bold tracking-widest text-gray-400 block pt-1">
                          Refined Target Tags
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {recommendation.smartTags.map((tag) => (
                            <button
                              key={tag}
                              onClick={() => handleApplySmartTag(tag)}
                              className="px-2 py-1 bg-[#F5F5F7] hover:bg-orange-50 hover:text-orange-600 transition text-[10px] font-mono font-semibold rounded text-gray-500 border border-gray-200 border-dashed cursor-pointer"
                              id={`tag-pill-${tag.replace(/\s+/g, '-').toLowerCase()}`}
                            >
                              #{tag}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Interactive Workspace Comparative setup tray */}
          <div className="bg-white border border-gray-100/80 rounded-3xl p-6 shadow-sm space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 bg-gray-50 text-gray-500 rounded-xl">
                <BookmarkPlus className="h-4.5 w-4.5" />
              </div>
              <div>
                <h3 className="font-sans font-bold text-[12px] text-gray-900 uppercase tracking-widest leading-none">
                  Curation Tray ({selectedProductIds.length})
                </h3>
                <span className="text-[9px] font-mono text-gray-400 block mt-1">Contrast item properties</span>
              </div>
            </div>

            {selectedProductIds.length === 0 ? (
              <p className="text-xs text-gray-400 leading-relaxed select-none">
                Click "Select for AI" on any products inside the list to group items. We can stack them here for comprehensive configuration.
              </p>
            ) : (
              <div className="space-y-2.5">
                <div className="space-y-2">
                  {selectedProductIds.map(id => {
                    const found = PRODUCTS.find(p => p.id === id);
                    if (!found) return null;
                    return (
                      <div 
                        key={id} 
                        className="flex items-center justify-between text-xs p-2.5 bg-[#F5F5F7]/70 rounded-xl border border-gray-100"
                        id={`tray-item-${id}`}
                      >
                        <span className="font-semibold text-gray-800 truncate max-w-[180px]">{found.title}</span>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-gray-600">{formatINR(found.price)}</span>
                          <button 
                            onClick={() => handleToggleProductId(id)}
                            className="text-gray-400 hover:text-red-500 p-0.5 cursor-pointer"
                          >
                            <X className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Simulated workspace dynamic sum parameters in INR */}
                <div className="pt-3.5 border-t border-gray-150/40 flex items-center justify-between text-xs font-semibold">
                  <span className="text-gray-400">Aggregated Cost:</span>
                  <span className="font-bold text-gray-900 text-sm">
                    {formatINR(aggregatedCostUSD)}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* System Status Telemetry summary */}
          <div className="bg-black text-white p-7 rounded-3xl flex flex-col justify-between overflow-hidden relative shadow-lg min-h-[220px]">
            <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500 rounded-full blur-3xl opacity-35" />
            <div className="relative z-10">
              <span className="text-[10px] font-bold uppercase tracking-widest text-orange-400">System Status</span>
              <h3 className="text-xl font-light mt-3 leading-snug">
                Algorithm is performing at <span className="font-semibold text-orange-400">99.8%</span> accuracy
              </h3>
            </div>
            <div className="relative z-10 space-y-3 mt-6 pt-4 border-t border-white/10 select-none">
              <div className="flex justify-between items-end pb-1 text-xs">
                <span className="text-white/50 font-semibold text-[10px] tracking-wider uppercase">Debounce Latency</span>
                <span className="font-mono text-white text-xs font-bold">{debounceSetting}ms</span>
              </div>
              <div className="flex justify-between items-end pb-1 text-xs">
                <span className="text-white/50 font-semibold text-[10px] tracking-wider uppercase">Vector Nodes</span>
                <span className="font-mono text-white text-xs font-bold">{latentNodes.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-end text-xs">
                <span className="text-white/50 font-semibold text-[10px] tracking-wider uppercase">Cache Hit Rate</span>
                <span className="font-mono text-white text-xs font-bold">
                  {simRunning ? "82.1%" : "Paused (0ms)"}
                </span>
              </div>
            </div>
          </div>

          {/* Search Cluster Distribution Widget */}
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex flex-col justify-between">
            <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">Search Cluster Distribution</h4>
            <div className="flex items-end justify-between h-24 gap-2 px-1">
               <div className="flex-1 bg-gray-100 rounded-t-md h-[40%] transition-all duration-300 hover:bg-orange-400" />
               <div className="flex-1 bg-gray-100 rounded-t-md h-[60%] transition-all duration-300 hover:bg-orange-400" />
               <div className="flex-1 bg-orange-500 rounded-t-md h-[95%] shadow-[0_4px_12px_rgba(250,130,49,0.2)]" />
               <div className="flex-1 bg-gray-100 rounded-t-md h-[75%] transition-all duration-300 hover:bg-orange-400" />
               <div className="flex-1 bg-gray-100 rounded-t-md h-[30%] transition-all duration-300 hover:bg-orange-400" />
               <div className="flex-1 bg-gray-100 rounded-t-md h-[55%] transition-all duration-300 hover:bg-orange-400" />
            </div>
            <div className="mt-4 flex justify-between text-[10px] font-bold text-gray-400 uppercase tracking-widest pl-1 pr-1 select-none">
              <span>Min-Peak</span>
              <span>Max-Cluster</span>
            </div>
          </div>

        </section>

        {/* RIGHT COLUMN: The Products Catalogue */}
        <section className="lg:col-span-8 space-y-6" id="product-results-column">
          
          {/* Dynamic Catalogue Controller bar */}
          <div className="bg-white border border-gray-100 rounded-3xl px-6 py-4 flex flex-wrap items-center justify-between gap-4 shadow-sm">
            <div className="flex items-center gap-2">
              <span className="text-[10.5px] font-bold text-gray-400 uppercase tracking-widest leading-none">
                Catalogue Grid ({sortedProducts.length})
              </span>
            </div>

            {/* Price sort controllers */}
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                onClick={() => setSortBy("relevance")}
                className={`px-3.5 py-2 rounded-full text-xs font-semibold transition cursor-pointer select-none flex items-center gap-1 ${
                  sortBy === "relevance"
                    ? "bg-orange-500 text-white shadow-sm"
                    : "bg-[#F5F5F7] text-gray-500 hover:bg-gray-100 hover:text-black"
                }`}
                title="Sort by AI relevance ordering"
                id="sort-btn-relevance"
              >
                <Sparkles className="h-3.5 w-3.5" />
                <span>AI Ranked</span>
              </button>

              <button
                onClick={() => setSortBy("price_asc")}
                className={`px-3.5 py-2 rounded-full text-xs font-semibold transition cursor-pointer select-none flex items-center gap-1 ${
                  sortBy === "price_asc"
                    ? "bg-orange-500 text-white shadow-sm"
                    : "bg-[#F5F5F7] text-gray-500 hover:bg-gray-100 hover:text-black"
                }`}
                id="sort-btn-price-asc"
              >
                <span>Price Low</span>
              </button>

              <button
                onClick={() => setSortBy("price_desc")}
                className={`px-3.5 py-2 rounded-full text-xs font-semibold transition cursor-pointer select-none flex items-center gap-1 ${
                  sortBy === "price_desc"
                    ? "bg-orange-500 text-white shadow-sm"
                    : "bg-[#F5F5F7] text-gray-500 hover:bg-gray-100 hover:text-black"
                }`}
                id="sort-btn-price-desc"
              >
                <span>Price High</span>
              </button>

              <button
                onClick={() => setSortBy("rating_desc")}
                className={`px-3.5 py-2 rounded-full text-xs font-semibold transition cursor-pointer select-none flex items-center gap-1 ${
                  sortBy === "rating_desc"
                    ? "bg-orange-500 text-white shadow-sm"
                    : "bg-[#F5F5F7] text-gray-500 hover:bg-gray-100 hover:text-black"
                }`}
                id="sort-btn-rating"
              >
                <span>Rating</span>
              </button>
            </div>
          </div>

          {/* Product grid rendered using currency mapping */}
          <div className="min-h-[400px]">
            {isProductsLoading ? (
              <GridSkeleton count={3} />
            ) : (
              <ProductGrid 
                products={sortedProducts} 
                selectedIds={selectedProductIds}
                onSelectId={handleToggleProductId}
              />
            )}
          </div>

        </section>

      </main>
    </motion.div>
  );
}
