import React from "react";
import { motion } from "motion/react";
import { Search, X } from "lucide-react";
import { formatINR } from "../modules/currency";
import { PRODUCTS } from "../modules/products";

interface InventoryViewProps {
  inventorySearch: string;
  setInventorySearch: (val: string) => void;
  inventoryFilter: string;
  setInventoryFilter: (val: string) => void;
  inventoryStock: Record<string, number>;
  setInventoryStock: React.Dispatch<React.SetStateAction<Record<string, number>>>;
}

export function InventoryView({
  inventorySearch,
  setInventorySearch,
  inventoryFilter,
  setInventoryFilter,
  inventoryStock,
  setInventoryStock
}: InventoryViewProps) {

  return (
    <motion.div
      key="inventory-view"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -12 }}
      transition={{ duration: 0.3 }}
      className="max-w-7xl mx-auto px-4 md:px-8 mt-12 space-y-8 min-h-[500px]"
    >
      <div className="text-center md:text-left space-y-2">
        <span className="text-[10px] font-mono uppercase tracking-[0.25em] font-bold text-orange-600 bg-orange-50/70 border border-orange-100/50 px-3.5 py-1.5 rounded-full inline-block">
          SYSTEM AUDITING MODULE
        </span>
        <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight">
          Physical Node Inventory Manager
        </h2>
        <p className="text-gray-400 text-xs md:text-sm max-w-2xl leading-relaxed">
          Review and recalibrate warehouse stock levels, pricing coordinates, and supply levels. Select Restock to supplement units.
        </p>
      </div>

      <div className="bg-white border border-gray-200/60 rounded-3xl p-6 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search inventory keywords..."
            value={inventorySearch}
            onChange={(e) => setInventorySearch(e.target.value)}
            className="w-full bg-[#F5F5F7] border border-transparent hover:border-gray-200 focus:border-black/30 focus:bg-white text-xs font-semibold pl-10 pr-4 py-2.5 rounded-xl outline-none transition-all"
          />
          {inventorySearch && (
            <button onClick={() => setInventorySearch("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-black">
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto select-none no-scrollbar">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mr-2 shrink-0">Filter Status:</span>
          {["All", "Low Stock", "In Stock"].map((filterOpt) => (
            <button
              key={filterOpt}
              onClick={() => setInventoryFilter(filterOpt)}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold transition cursor-pointer select-none whitespace-nowrap ${
                inventoryFilter === filterOpt
                  ? "bg-black text-white shadow-sm font-bold"
                  : "bg-[#F5F5F7] text-gray-500 hover:bg-gray-200"
              }`}
            >
              {filterOpt}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-3xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-gray-200 py-3 bg-[#F5F5F7]/50 text-[10px] uppercase font-mono tracking-widest text-gray-400 select-none">
                <th className="px-6 py-4">Workspace Node Item</th>
                <th className="px-6 py-4">Static Category</th>
                <th className="px-6 py-4">Monospace SKU / ID</th>
                <th className="px-6 py-4">Unit Pricing (INR)</th>
                <th className="px-6 py-4">Manifold Stock Status</th>
                <th className="px-6 py-4 text-right">Interactive Adjustments</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-xs font-sans">
              {PRODUCTS.map((p) => {
                const stock = inventoryStock[p.id] !== undefined ? inventoryStock[p.id] : 5;
                const matchesSearch = p.title.toLowerCase().includes(inventorySearch.toLowerCase());
                const matchesStatus = 
                  inventoryFilter === "All" || 
                  (inventoryFilter === "Low Stock" && stock <= 3) || 
                  (inventoryFilter === "In Stock" && stock > 3);

                if (!matchesSearch || !matchesStatus) return null;

                const isLow = stock <= 3;

                return (
                  <tr key={p.id} className="hover:bg-[#F5F5F7]/30 transition-colors">
                    <td className="px-6 py-4 font-semibold text-gray-900">
                      {p.title}
                    </td>
                    <td className="px-6 py-4 text-gray-500 font-semibold uppercase text-[10px] tracking-wider font-mono">
                      {p.id === "prod-1" || p.id === "prod-7" ? "Keyboards & Typing" :
                       p.id === "prod-2" || p.id === "prod-6" ? "Desk & Organization" :
                       p.id === "prod-3" || p.id === "prod-8" ? "Audio & Acoustics" :
                       p.id === "prod-4" || p.id === "prod-10" ? "Lighting & Ambiance" :
                       "Power & Charging"}
                    </td>
                    <td className="px-6 py-4 font-mono font-bold tracking-tight text-gray-400 select-text">
                      SKU-{p.id.toUpperCase()}-LATENT
                    </td>
                    <td className="px-6 py-4 font-bold text-gray-900 font-mono text-[13px]">
                      {formatINR(p.price)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {isLow ? (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider bg-rose-50 text-rose-600 border border-rose-100 animate-pulse">
                          Low Stock ({stock})
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider bg-emerald-50 text-emerald-600 border border-emerald-100">
                          In Stock ({stock})
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="inline-flex gap-2">
                        <button
                          onClick={() => {
                            setInventoryStock(prev => ({
                              ...prev,
                              [p.id]: Math.max(0, (prev[p.id] || 0) - 1)
                            }));
                          }}
                          className="px-2.5 py-1.5 bg-[#F5F5F7] hover:bg-rose-50 hover:text-rose-600 rounded-lg text-[10px] font-mono font-bold transition uppercase cursor-pointer pointer-events-auto"
                        >
                          - Sell Unit
                        </button>
                        <button
                          onClick={() => {
                            setInventoryStock(prev => ({
                              ...prev,
                              [p.id]: (prev[p.id] || 0) + 5
                            }));
                          }}
                          className="px-2.5 py-1.5 bg-black hover:bg-orange-500 hover:text-white text-white rounded-lg text-[10px] font-mono font-bold transition uppercase shadow-sm cursor-pointer pointer-events-auto"
                        >
                          + Restock (+5)
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </motion.div>
  );
}
