import React from "react";
import { motion } from "motion/react";

export const CardSkeleton: React.FC = () => {
  return (
    <div className="bg-white border border-gray-100/80 rounded-2xl p-5 overflow-hidden shadow-[0_4px_20px_rgba(0,0,0,0.01)] flex flex-col justify-between h-[390px] relative">
      <div>
        {/* Aspect-ratio matched rounded space for image block */}
        <div className="relative w-full h-[180px] bg-gray-100 animate-pulse rounded-xl overflow-hidden mb-4" />

        {/* Title skeleton */}
        <div className="h-5 w-3/4 bg-gray-100 animate-pulse rounded-md mb-2" />

        {/* Category badge skeleton */}
        <div className="h-3 w-1/3 bg-gray-50 animate-pulse rounded-md mb-3" />

        {/* Specs skeleton lines */}
        <div className="space-y-1.5 mb-4">
          <div className="h-3 w-5/6 bg-gray-50/80 animate-pulse rounded" />
          <div className="h-3 w-2/3 bg-gray-50/80 animate-pulse rounded" />
        </div>
      </div>

      <div className="flex items-center justify-between pt-3 border-t border-gray-50">
        {/* Price skeleton */}
        <div className="h-5 w-1/4 bg-gray-100 animate-pulse rounded-md" />
        {/* Interactive button skeleton */}
        <div className="h-7 w-20 bg-gray-100 animate-pulse rounded-lg" />
      </div>
    </div>
  );
};

export const GridSkeleton: React.FC<{ count?: number }> = ({ count = 3 }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 w-full">
      {Array.from({ length: count }).map((_, i) => (
        <CardSkeleton key={i} />
      ))}
    </div>
  );
};

export const AIRecommendationSkeleton: React.FC = () => {
  return (
    <div className="w-full bg-orange-50/30 border border-orange-100/50 rounded-2xl p-6 mb-8 shadow-sm">
      <div className="flex items-start gap-4">
        <div className="p-2.5 bg-orange-100/30 text-orange-500 rounded-xl animate-pulse">
          <div className="w-5 h-5" />
        </div>
        <div className="flex-1 space-y-3">
          <div className="h-3.5 w-1/4 bg-orange-100/20 animate-pulse rounded" />
          <div className="space-y-2">
            <div className="h-3.5 bg-orange-100/10 animate-pulse rounded" />
            <div className="h-3.5 bg-orange-100/10 animate-pulse rounded" />
            <div className="h-3.5 w-2/3 bg-orange-100/10 animate-pulse rounded" />
          </div>

          <div className="pt-4 flex flex-wrap gap-2">
            <div className="h-5 w-16 bg-orange-100/20 animate-pulse rounded-full" />
            <div className="h-5 w-24 bg-orange-100/20 animate-pulse rounded-full" />
            <div className="h-5 w-20 bg-orange-100/20 animate-pulse rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
};
