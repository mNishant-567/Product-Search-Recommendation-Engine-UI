import { Search } from "lucide-react";

interface NavigationProps {
  activeNav: string;
  setActiveNav: (nav: string) => void;
}

export function Navigation({ activeNav, setActiveNav }: NavigationProps) {
  const navItems = ["Dashboard", "Inventory", "Analytics", "Settings"];

  return (
    <>
      {/* Premium top minimal announcement segment */}
      <div className="w-full bg-white border-b border-gray-200 py-3 px-4 text-center text-[10px] font-mono tracking-wider text-gray-400 uppercase select-none">
        ✦ Dynamic Latent Search Engine Powered by Google Gemini-3.5-Flash Server-Side AI ✦
      </div>

      {/* Product&co Sophisticated Navigation Bar */}
      <nav className="flex items-center justify-between px-6 md:px-12 py-5 bg-white/85 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50 select-none">
        <div className="flex items-center space-x-2.5 cursor-pointer" onClick={() => setActiveNav("Dashboard")}>
          <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center shadow-md">
            <Search className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold text-lg tracking-tight text-black">Product&amp;co</span>
        </div>
        
        {/* Desktop navbar menu - fully responsive and stateful */}
        <div className="hidden md:flex space-x-8 text-xs font-semibold text-gray-400 uppercase tracking-wider" id="navbar-menu-container">
          {navItems.map((navItem) => {
            const isActive = activeNav === navItem;
            return (
              <span
                key={navItem}
                onClick={() => setActiveNav(navItem)}
                className={`cursor-pointer transition-all duration-200 pb-1 ${
                  isActive 
                    ? "text-black border-b-2 border-black font-bold" 
                    : "text-gray-400 hover:text-black"
                }`}
                id={`nav-${navItem.toLowerCase()}`}
              >
                {navItem}
              </span>
            );
          })}
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <div className="text-[11px] font-bold text-gray-900 leading-none">Creative Director</div>
            <div className="text-[9px] font-mono text-orange-500 font-semibold uppercase tracking-wider mt-0.5">Online</div>
          </div>
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-orange-400 to-rose-400 border-2 border-white shadow-sm flex items-center justify-center text-xs text-white font-bold font-mono">N</div>
        </div>
      </nav>

      {/* Mobile horizontal navigation drawer fallback tab list */}
      <div className="md:hidden flex overflow-x-auto space-x-2 px-4 py-3 bg-white border-b border-gray-200 select-none scrollbar-none" id="mobile-tabs-container">
        {navItems.map((navItem) => {
          const isActive = activeNav === navItem;
          return (
            <button
              key={navItem}
              onClick={() => setActiveNav(navItem)}
              className={`flex-shrink-0 px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider transition-all duration-200 ${
                isActive 
                  ? "bg-black text-white shadow-md" 
                  : "bg-gray-100 text-gray-500 hover:bg-gray-200"
              }`}
            >
              {navItem}
            </button>
          );
        })}
      </div>
    </>
  );
}
