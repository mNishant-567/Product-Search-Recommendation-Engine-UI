import React, { useState } from "react";
import { motion } from "motion/react";
import { Star, ArrowRight, Info, Plus, ChevronDown, ChevronUp, Check, BadgePercent } from "lucide-react";
import { Product } from "../types";
import { formatINR } from "../modules/currency";

interface ProductCardProps {
  product: Product;
  index: number;
  isSelected?: boolean;
  onSelect?: () => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  index,
  isSelected = false,
  onSelect
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Stagger index variants for initial presentation
  const cardVariants = {
    hidden: { opacity: 0, y: 16 },
    show: { 
      opacity: 1, 
      y: 0,
      transition: {
        type: "spring",
        stiffness: 260,
        damping: 24,
      }
    }
  };

  return (
    <motion.div
      variants={cardVariants}
      layout="position"
      id={`product-card-${product.id}`}
      className={`group relative bg-white border p-5 rounded-3xl transition-all duration-300 hover:shadow-xl hover:border-orange-100 ${
        isSelected ? "border-orange-200 ring-4 ring-orange-100/30" : "border-gray-100 shadow-sm"
      }`}
    >
      <div>
        {/* Absolute category pill tag on top of image alongside Match score */}
        <div className="absolute top-8 left-8 z-10 flex gap-2">
          <span className="px-2.5 py-1 text-[10px] font-semibold tracking-wider uppercase bg-white/95 backdrop-blur-md text-gray-800 rounded-lg shadow-sm border border-gray-100">
            {product.category}
          </span>
          <span className="px-2 py-1 bg-orange-600/95 backdrop-blur-md text-white text-[10px] font-bold rounded-lg shadow-sm">
            {Math.round(85 + (product.rating - 4.4) * 30 > 99 ? 99 : 85 + (product.rating - 4.4) * 30)}% MATCH
          </span>
        </div>

        {/* Scaled Product Image Container */}
        <div className="relative w-full h-[180px] bg-[#F5F5F7] rounded-2xl overflow-hidden mb-4">
          <motion.img
            src={product.image}
            alt={product.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover grayscale-[8%] group-hover:grayscale-0 transition-all duration-700 font-sans"
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.4 }}
          />

          <div className="absolute bottom-3 right-3 flex items-center gap-1 px-2 py-0.5 bg-black/60 backdrop-blur-sm rounded-md text-white text-[11px] font-sans font-medium">
            <Star className="h-3 w-3 fill-amber-400 stroke-amber-400" />
            <span>{product.rating.toFixed(1)}</span>
          </div>
        </div>

        {/* Title and Description */}
        <div className="mb-3">
          <h3 className="font-sans font-bold text-gray-900 text-sm md:text-base leading-tight tracking-tight group-hover:text-orange-500 transition-colors">
            {product.title}
          </h3>
          <p className="mt-1.5 text-xs text-gray-400 leading-relaxed font-normal">
            {product.description}
          </p>
        </div>

        {/* Dynamic Expandable Details Segment */}
        <div className="mt-2 text-xs">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center gap-1.5 text-gray-400 hover:text-gray-600 transition-colors cursor-pointer select-none py-1"
            aria-expanded={isExpanded}
            id={`details-toggle-${product.id}`}
          >
            <span className="font-semibold text-[10px] tracking-wider uppercase">Technical Specifications</span>
            {isExpanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
          </button>

          {isExpanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              className="mt-2.5 pt-2.5 border-t border-gray-100 text-[10.5px] font-mono text-gray-500 space-y-2 select-none"
            >
              <div className="space-y-1">
                <span className="text-[9px] uppercase font-bold text-gray-400 tracking-wider">Specifications:</span>
                <ul className="list-disc pl-4 space-y-1 text-gray-600">
                  {product.specs.map((spec, i) => (
                    <li key={i}>{spec}</li>
                  ))}
                </ul>
              </div>

              <div className="space-y-1">
                <span className="text-[9px] uppercase font-bold text-gray-400 tracking-wider">Features:</span>
                <ul className="list-disc pl-4 space-y-1 text-gray-600">
                  {product.features.map((feat, i) => (
                    <li key={i}>{feat}</li>
                  ))}
                </ul>
              </div>
            </motion.div>
          )}
        </div>
      </div>

      <div className="mt-5 pt-3.5 border-t border-gray-100 flex items-center justify-between">
        <div className="flex flex-col">
          <span className="text-[9px] text-gray-400 uppercase tracking-widest leading-none">Price</span>
          <span className="text-base font-bold text-gray-950">{formatINR(product.price)}</span>
        </div>

        {onSelect && (
          <button
            onClick={onSelect}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-sans font-semibold transition-all duration-300 active:scale-95 cursor-pointer ${
              isSelected
                ? "bg-orange-500 text-white shadow-sm hover:bg-orange-600"
                : "bg-black text-white hover:bg-orange-500"
            }`}
            id={`select-btn-${product.id}`}
          >
            {isSelected ? (
              <>
                <Check className="h-3 w-3 stroke-[3]" />
                <span>Selected</span>
              </>
            ) : (
              <>
                <Plus className="h-3 w-3" />
                <span>Select for AI</span>
              </>
            )}
          </button>
        )}
      </div>
    </motion.div>
  );
};
