import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { ProductCard } from "./ProductCard";
import { Product } from "../types";
import { Sparkles, AlertCircle } from "lucide-react";

interface ProductGridProps {
  products: Product[];
  selectedIds: string[];
  onSelectId: (id: string) => void;
}

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  selectedIds,
  onSelectId
}) => {
  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08,
        delayChildren: 0.02
      }
    }
  };

  return (
    <div className="w-full" id="product-grid-section">
      <AnimatePresence mode="popLayout">
        {products.length === 0 ? (
          <motion.div
            key="empty-state"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            className="flex flex-col items-center justify-center py-20 text-center border border-dashed border-gray-100 rounded-3xl bg-white"
          >
            <div className="p-3.5 bg-gray-50 text-gray-400 rounded-full mb-4">
              <AlertCircle className="h-6 w-6 stroke-[1.5]" />
            </div>
            <h3 className="font-sans font-medium text-gray-800 text-base">No products match your search</h3>
            <p className="text-gray-400 text-xs mt-1 md:max-w-sm px-4">
              Try adjusting your query or filters. You can search by product name, features, or broader setup keywords like "tactile" or "studio".
            </p>
          </motion.div>
        ) : (
          <motion.div
            key="grid-container"
            variants={containerVariants}
            initial="hidden"
            animate="show"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 w-full"
          >
            <AnimatePresence mode="popLayout">
              {products.map((product, idx) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  index={idx}
                  isSelected={selectedIds.includes(product.id)}
                  onSelect={() => onSelectId(product.id)}
                />
              ))}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
