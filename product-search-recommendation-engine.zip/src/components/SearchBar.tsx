import React, { useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Search, X, Command, Sparkles } from "lucide-react";

interface SearchBarProps {
  value: string;
  onChange: (val: string) => void;
  isLoading: boolean;
  onClear: () => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  value,
  onChange,
  isLoading,
  onClear
}) => {
  const inputRef = useRef<HTMLInputElement>(null);

  // Keyboard shortcut support: '/' to focus, 'Esc' to clear
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "/" && document.activeElement !== inputRef.current) {
        e.preventDefault();
        inputRef.current?.focus();
      } else if (e.key === "Escape" && document.activeElement === inputRef.current) {
        onClear();
        inputRef.current?.blur();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClear]);

  return (
    <div className="w-full max-w-2xl mx-auto mb-10" id="search-bar-container">
      <div className="relative">
        <div className="relative flex items-center bg-white h-16 rounded-2xl shadow-[0_0_0_1px_rgba(0,0,0,0.05),0_10px_40px_-10px_rgba(0,0,0,0.08)] outline-none focus-within:ring-4 focus-within:ring-orange-500/10 transition-all border border-transparent focus-within:border-orange-500/20">
          <div className="flex items-center pl-6 pr-2 text-orange-500">
            <Search className="h-5 w-5 stroke-[2]" />
          </div>

          <input
            ref={inputRef}
            type="text"
            className="w-full h-full bg-transparent text-[16px] font-sans text-gray-800 placeholder-gray-400 outline-none pr-28 pl-2 font-medium"
            placeholder="Search products or goals... (e.g., 'compact high-fidelity')"
            value={value}
            aria-label="Search items"
            id="search-input-field"
            onChange={(e) => onChange(e.target.value)}
          />

          <div className="absolute right-6 top-1/2 -translate-y-1/2 flex items-center space-x-3 bg-white pl-2">
            <AnimatePresence mode="popLayout">
              {isLoading && (
                <motion.div
                  key="loader"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="mr-1"
                >
                  <div className="w-4 h-4 rounded-full border-2 border-orange-500/20 border-t-orange-500 animate-spin" />
                </motion.div>
              )}
            </AnimatePresence>

            <AnimatePresence>
              {value ? (
                <motion.button
                  key="clear"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  onClick={onClear}
                  className="p-1.5 text-gray-400 hover:text-gray-600 transition-colors hover:bg-gray-50 rounded-lg cursor-pointer"
                  title="Clear search"
                  id="search-clear-button"
                >
                  <X className="h-4 w-4 stroke-[2]" />
                </motion.button>
              ) : (
                <motion.div
                  key="kbd"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 0.6 }}
                  exit={{ opacity: 0 }}
                  className="hidden sm:flex items-center gap-0.5 px-2 py-1 bg-gray-50 rounded border border-gray-100 text-[10px] font-mono font-bold text-gray-400 select-none"
                >
                  <Command className="h-2.5 w-2.5" />
                  <span>K</span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Live feedback absolute metadata badge */}
        <div className="absolute -bottom-6 left-6 flex items-center space-x-3 select-none">
          <span className="text-[9px] uppercase tracking-widest text-gray-400 font-bold">Live Feedback</span>
          <div className="flex items-center space-x-1 border-l border-gray-200 pl-3">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
            <span className="text-[9px] font-semibold text-gray-500">Engine: Latent Manifold v4.2</span>
          </div>
        </div>
      </div>

      {/* Recommended sample prompts under search bar */}
      <div className="mt-10 flex flex-wrap items-center justify-center gap-2 text-xs text-gray-400 font-sans">
        <span className="flex items-center gap-1 text-[10px] uppercase tracking-wider font-bold text-gray-400">
          <Sparkles className="h-3.5 w-3.5 text-orange-400" /> Inspired prompts:
        </span>
        <button
          onClick={() => onChange("mechanical keyboard comfort")}
          className="px-3 py-1 bg-white hover:bg-orange-50 hover:text-orange-600 hover:border-orange-100 transition duration-300 border border-gray-250/20 rounded-full cursor-pointer shadow-sm text-[11px] font-medium"
        >
          mechanical keyboard
        </button>
        <button
          onClick={() => onChange("high-fidelity studio setup")}
          className="px-3 py-1 bg-white hover:bg-orange-50 hover:text-orange-600 hover:border-orange-100 transition duration-300 border border-gray-250/20 rounded-full cursor-pointer shadow-sm text-[11px] font-medium"
        >
          fidelity studio setup
        </button>
        <button
          onClick={() => onChange("desk lightning")}
          className="px-3 py-1 bg-white hover:bg-orange-50 hover:text-orange-600 hover:border-orange-100 transition duration-300 border border-gray-250/20 rounded-full cursor-pointer shadow-sm text-[11px] font-medium"
        >
          ambiance & desk light
        </button>
      </div>
    </div>
  );
};
