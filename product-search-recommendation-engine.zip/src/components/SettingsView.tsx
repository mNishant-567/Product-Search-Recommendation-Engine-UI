import React from "react";
import { motion } from "motion/react";
import { Trash2, Play, Pause, RefreshCw } from "lucide-react";

interface SettingsViewProps {
  engineTemp: number;
  setEngineTemp: (val: number) => void;
  latentNodes: number;
  setLatentNodes: (val: number) => void;
  debounceSetting: number;
  setDebounceSetting: (val: number) => void;
  simRunning: boolean;
  setSimRunning: (val: boolean) => void;
  systemLogs: string[];
  setSystemLogs: React.Dispatch<React.SetStateAction<string[]>>;
  setSelectedProductIds: (val: string[]) => void;
}

export function SettingsView({
  engineTemp,
  setEngineTemp,
  latentNodes,
  setLatentNodes,
  debounceSetting,
  setDebounceSetting,
  simRunning,
  setSimRunning,
  systemLogs,
  setSystemLogs,
  setSelectedProductIds
}: SettingsViewProps) {

  return (
    <motion.div
      key="settings-view"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -12 }}
      transition={{ duration: 0.3 }}
      className="max-w-4xl mx-auto px-4 mt-12 space-y-8 min-h-[500px]"
    >
      <div className="text-center md:text-left space-y-2">
        <span className="text-[10px] font-mono uppercase tracking-[0.25em] font-bold text-orange-600 bg-orange-50/70 border border-orange-100/50 px-3.5 py-1.5 rounded-full inline-block">
          SYSTEM CALIBRATION
        </span>
        <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight">
          Model Engine Parameter Controls
        </h2>
        <p className="text-gray-400 text-xs md:text-sm max-w-xl leading-relaxed">
          Tweak live input debounce intervals, adjust active vector mapping nodes count, and test self-diagnostics coordinates.
        </p>
      </div>

      <div className="bg-white border border-gray-200 rounded-3xl p-6 md:p-8 shadow-sm space-y-8">
        
        <div className="space-y-3">
          <div className="flex justify-between items-center text-xs">
            <div>
              <label className="font-extrabold text-gray-900 uppercase tracking-wider block">Debounce Process Latency</label>
              <span className="text-[9.5px] text-gray-400 font-sans block mt-0.5">Controls input filter lag to prevent unnecessary server calculation load.</span>
            </div>
            <span className="font-mono text-orange-500 font-bold bg-orange-50 px-2.5 py-1 rounded text-xs select-none">
              {debounceSetting}ms
            </span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-1 select-none">
            {[100, 250, 350, 500, 1000].map((ms) => {
              const isSelected = debounceSetting === ms;
              return (
                <button
                  key={ms}
                  onClick={() => {
                    setDebounceSetting(ms);
                    setSystemLogs(prev => [
                      `[${new Date().toLocaleTimeString()}] DELAY_UPDATE: Debounce changed to ${ms}ms.`,
                      ...prev.slice(0, 5)
                    ]);
                  }}
                  className={`py-2 px-1 rounded-xl text-[11px] font-semibold transition cursor-pointer text-center select-none ${
                    isSelected 
                      ? "bg-black text-white shadow-sm font-bold"
                      : "bg-[#F5F5F7] text-gray-500 hover:bg-gray-200"
                  }`}
                >
                  {ms === 100 ? "100ms (Fast)" :
                   ms === 250 ? "250ms (Balanced)" :
                   ms === 350 ? "350ms (Default)" :
                   ms === 500 ? "500ms (Stable)" : "1000ms (Lag)"}
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-3 pt-4 border-t border-gray-100">
          <div className="flex justify-between items-center text-xs">
            <div>
              <label className="font-extrabold text-gray-900 uppercase tracking-wider block">Latent Match Temperature</label>
              <span className="text-[9.5px] text-gray-400 font-sans block mt-0.5">Adjust how strict vs extrapolative the recommendation module coordinates companions.</span>
            </div>
            <span className="font-mono text-orange-500 font-bold bg-orange-50 px-2.5 py-1 rounded text-xs select-none">
              {engineTemp.toFixed(2)}
            </span>
          </div>
          
          <input
            type="range"
            min="0.1"
            max="1.0"
            step="0.05"
            value={engineTemp}
            onChange={(e) => {
              const val = parseFloat(e.target.value);
              setEngineTemp(val);
              if (Math.random() > 0.6) {
                setSystemLogs(prev => [
                  `[${new Date().toLocaleTimeString()}] MODEL_TEMP: Recalibrated temperature to ${val}.`,
                  ...prev.slice(0, 5)
                ]);
              }
            }}
            className="w-full accent-orange-500 cursor-pointer pointer-events-auto"
          />
          <div className="flex justify-between text-[10px] font-mono text-gray-400 font-semibold select-none">
            <span>Strict Deterministic (0.1)</span>
            <span>Extrapolative Creative (1.0)</span>
          </div>
        </div>

        <div className="space-y-3 pt-4 border-t border-gray-100">
          <div className="flex justify-between items-center text-xs">
            <div>
              <label className="font-extrabold text-gray-900 uppercase tracking-wider block font-sans">Active Target Vector Nodes</label>
              <span className="text-[9.5px] text-gray-400 font-sans block mt-0.5">Adjust high-dimensional mapping counts (linked live to status widgets).</span>
            </div>
            <span className="font-mono text-orange-500 font-bold bg-orange-50 px-2.5 py-1 rounded text-xs select-none">
              {latentNodes.toLocaleString()} Points
            </span>
          </div>
          
          <input
            type="range"
            min="2000"
            max="30000"
            step="500"
            value={latentNodes}
            onChange={(e) => {
              const val = parseInt(e.target.value);
              setLatentNodes(val);
            }}
            className="w-full accent-orange-500 cursor-pointer pointer-events-auto"
          />
        </div>

        <div className="pt-6 border-t border-gray-200 flex flex-wrap gap-3 select-none">
          <button
            onClick={() => {
              setSelectedProductIds([]);
              setSystemLogs(prev => [
                `[${new Date().toLocaleTimeString()}] TRASH_PURGED: Cleared all items from curation tray.`,
                ...prev.slice(0, 5)
              ]);
            }}
            className="px-4 py-2.5 bg-rose-50 text-rose-500 text-xs font-bold font-mono rounded-xl hover:bg-rose-100 transition whitespace-nowrap uppercase flex items-center gap-1.5 cursor-pointer shadow-sm pointer-events-auto"
          >
            <Trash2 className="h-4 w-4" />
            Purge Curation Tray
          </button>

          <button
            onClick={() => {
              setSimRunning(!simRunning);
              setSystemLogs(prev => [
                `[${new Date().toLocaleTimeString()}] SIM_TOGGLE: Telemetry background stream toggled ${!simRunning ? "ON" : "OFF"}.`,
                ...prev.slice(0, 5)
              ]);
            }}
            className={`px-4 py-2.5 text-xs font-bold font-mono rounded-xl transition whitespace-nowrap uppercase flex items-center gap-1.5 cursor-pointer shadow-sm pointer-events-auto ${
              simRunning 
                ? "bg-amber-50 text-amber-600 hover:bg-amber-100" 
                : "bg-emerald-50 text-emerald-600 hover:bg-emerald-100"
            }`}
          >
            {simRunning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            {simRunning ? "Pause Telemetry" : "Resume Telemetry"}
          </button>

          <button
            onClick={() => {
              const randomId = Math.floor(1000 + Math.random() * 9000);
              setSystemLogs(prev => [
                `[${new Date().toLocaleTimeString()}] SYSTEM_DIAG: Core test verified successfully. DIAG-${randomId}-LNT`,
                `[${new Date().toLocaleTimeString()}] INDEX_FLUSH: Refreshed intent cluster embedding maps.`,
                ...prev.slice(0, 5)
              ]);
            }}
            className="px-4 py-2.5 bg-gray-100 text-gray-600 text-xs font-bold font-mono rounded-xl hover:bg-gray-200 transition whitespace-nowrap uppercase flex items-center gap-1.5 cursor-pointer shadow-sm pointer-events-auto"
          >
            <RefreshCw className="h-4 w-4" />
            Diagnostic Report
          </button>
        </div>

      </div>

      <div className="bg-black text-emerald-400 font-mono p-6 rounded-3xl space-y-3 shadow-lg text-[11px] border border-emerald-950/60 transition-all duration-300">
        <div className="flex justify-between items-center text-[9px] text-zinc-500 uppercase font-bold tracking-widest pb-2 border-b border-zinc-900 select-none">
          <span>Core Console Receiver Stream</span>
          <span className="flex items-center gap-1.5 text-emerald-500 font-bold uppercase tracking-wider">
            <span className={`w-1.5 h-1.5 rounded-full bg-emerald-400 ${simRunning ? "animate-pulse" : "bg-neutral-600"}`} />
            {simRunning ? "Live Streaming" : "Suspended"}
          </span>
        </div>
        <div className="space-y-1 select-text min-h-[96px]">
          {systemLogs.map((log, index) => (
            <p key={index} className="leading-relaxed hover:text-white transition-colors cursor-default">
              {log}
            </p>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
