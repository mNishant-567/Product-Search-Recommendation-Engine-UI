import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { BookOpen, Code, Layers, Zap, Info, ArrowUpRight, HelpCircle } from "lucide-react";

export const SyllabusInsights: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"architecture" | "state" | "rendering">("architecture");

  return (
    <div id="syllabus-insights-section" className="mt-14 w-full max-w-7xl mx-auto">
      <div className="bg-gradient-to-br from-gray-900 to-gray-950 text-white rounded-3xl p-6 md:p-8 shadow-[0_12px_40px_rgba(0,0,0,0.12)] border border-gray-800 relative overflow-hidden">
        {/* Background ambient lighting blobs */}
        <div className="absolute -top-12 -right-12 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-gray-800">
          <div className="flex items-center gap-3.5">
            <div className="p-3 bg-gray-800/80 rounded-2xl border border-gray-700/50">
              <BookOpen className="h-6 w-6 text-orange-400" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-semibold text-orange-400 tracking-widest">Syllabus Reference Alignment</span>
              <h2 className="font-sans font-semibold text-lg md:text-xl text-white tracking-tight mt-0.5">
                Front-End Engineering & Systems Architecture
              </h2>
            </div>
          </div>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="px-5 py-2.5 bg-white/10 hover:bg-white/15 active:scale-98 transition rounded-xl text-xs font-medium tracking-wide flex items-center justify-center gap-1.5 cursor-pointer border border-white/5"
            id="alignment-toggle-button"
          >
            <span>{isOpen ? "Hide Engineering Insights" : "View Curriculum Alignment"}</span>
            <ArrowUpRight className={`h-3.5 w-3.5 transition-transform duration-300 ${isOpen ? "rotate-45" : ""}`} />
          </button>
        </div>

        {!isOpen ? (
          <p className="mt-4 text-xs text-gray-400 leading-relaxed font-sans max-w-3xl">
            This workspace search and recommendation dashboard is custom engineered around standard front-end framework guidelines. Click <strong>"View Curriculum Alignment"</strong> to explore the deep implementation mapping (React reconciliation, race conditions, debounced event sequences, and skeleton layouts).
          </p>
        ) : (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="mt-6 font-sans"
          >
            <div className="flex flex-wrap gap-2 mb-6 border-b border-gray-800 pb-4">
              <button
                onClick={() => setActiveTab("architecture")}
                className={`px-4 py-2 rounded-xl text-xs font-medium cursor-pointer transition ${
                  activeTab === "architecture" ? "bg-orange-500 text-white" : "bg-gray-800/70 text-gray-400 hover:text-white"
                }`}
              >
                1. Async Flow & Race Conditions (CO4)
              </button>
              <button
                onClick={() => setActiveTab("state")}
                className={`px-4 py-2 rounded-xl text-xs font-medium cursor-pointer transition ${
                  activeTab === "state" ? "bg-orange-500 text-white" : "bg-gray-800/70 text-gray-400 hover:text-white"
                }`}
              >
                2. Unified UI & Pure Functions (CO2)
              </button>
              <button
                onClick={() => setActiveTab("rendering")}
                className={`px-4 py-2 rounded-xl text-xs font-medium cursor-pointer transition ${
                  activeTab === "rendering" ? "bg-orange-500 text-white" : "bg-gray-800/70 text-gray-400 hover:text-white"
                }`}
              >
                3. Key-Reconciliation & Layout Safety (CO5)
              </button>
            </div>

            <div className="bg-gray-900/50 rounded-2xl p-5 border border-gray-800/80 text-xs">
              <AnimatePresence mode="wait">
                {activeTab === "architecture" && (
                  <motion.div
                    key="arch"
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    transition={{ duration: 0.15 }}
                    className="space-y-4"
                  >
                    <div className="flex items-start gap-3">
                      <Zap className="h-4 w-4 text-orange-400 shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-gray-100 text-[13px] leading-tight">Asynchronous Sequencing & Race Conditions</h4>
                        <p className="mt-1 text-gray-400 leading-relaxed">
                          In standard frameworks, searching is triggered via keystrokes. Rapid keystrokes trigger multiple queries in parallel. If a slower query completes after a faster one, it leads to a <strong>Race Condition</strong> where outdated results replace current results. 
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <Code className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-gray-100 text-[13px] leading-tight flex items-center gap-1.5 font-mono">
                          useDebounce (Rate Limiting)
                        </h4>
                        <p className="mt-1 text-gray-400 leading-relaxed">
                          We mitigate this by applying a <code>useDebounce</code> mechanical key loop that pauses API hits for <strong>350ms</strong>. In addition, we employ a mounting sequence counter on our API fetch triggers so that late-arriving responses are discarded if a newer transaction has already been initiated.
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === "state" && (
                  <motion.div
                    key="state"
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    transition={{ duration: 0.15 }}
                    className="space-y-4"
                  >
                    <div className="flex items-start gap-3">
                      <Layers className="h-4 w-4 text-orange-400 shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-gray-100 text-[13px] leading-tight">Controlled UI State and Flow Architecture</h4>
                        <p className="mt-1 text-gray-400 leading-relaxed">
                          All state transformations in this application adhere to <strong>unidirectional data flow</strong>. The search query state is raised to the parent component (<code>App.tsx</code>), acting as the single source of truth that cascades changes cleanly to the children components.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <Code className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-gray-100 text-[13px] leading-tight">Immutability & Pure Components</h4>
                        <p className="mt-1 text-gray-400 leading-relaxed">
                          Our filtering logic operates purely through array transformations (<code>filter()</code> and <code>map()</code>), preserving state immutability. No variables are mutated directly, allowing React to trigger render pipelines predictably according to state updates.
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === "rendering" && (
                  <motion.div
                    key="render"
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    transition={{ duration: 0.15 }}
                    className="space-y-4"
                  >
                    <div className="flex items-start gap-3">
                      <Info className="h-4 w-4 text-orange-400 shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-gray-100 text-[13px] leading-tight">Keying & Virtual DOM Reconciliation</h4>
                        <p className="mt-1 text-gray-400 leading-relaxed">
                          Inside `ProductGrid.tsx`, we supply unique and stable keys to our product items (<code>product.id</code> instead of array indexes). When items reorder or exit, this key reference allows React's diffing engine to identify exactly which DOM elements have moved, bypassing slow bulk re-mounts.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <Layers className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-gray-100 text-[13px] leading-tight">Cumulative Layout Shift (CLS) Mitigation</h4>
                        <p className="mt-1 text-gray-400 leading-relaxed">
                          To comply with performance engineering standards (Lighthouse metrics), we ensure there is <strong>no layout shift</strong> when displaying skeletons. The skeleton cards mirror the exact sizing, margins, paddings, and aspect ratios of the loaded product grid.
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};
