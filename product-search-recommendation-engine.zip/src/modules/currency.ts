/**
 * Product&co Currency Utility Module
 * Specializes in formatting and converting values to Indian Rupees (₹).
 */

const USD_TO_INR_RATE = 83; // Approximate conversion rate for realistic Indian Rupees

/**
 * Formats a USD amount into Indian Rupees representation with elegant formatting (e.g. ₹11,537).
 */
export const formatINR = (valueUSD: number): string => {
  const inrAmount = Math.round(valueUSD * USD_TO_INR_RATE);
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0
  }).format(inrAmount);
};
