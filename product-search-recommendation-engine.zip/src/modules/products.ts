export interface CatalogProduct {
  id: string;
  title: string;
  price: number;
}

// Curated internal workspace catalogue matching our node database
export const PRODUCTS: CatalogProduct[] = [
  {
    id: "prod-1",
    title: "NuPhy Air75 V2 Keyboard",
    price: 139,
  },
  {
    id: "prod-2",
    title: "Merino Wool Desk Mat",
    price: 79,
  },
  {
    id: "prod-3",
    title: "Sennheiser HD 490 Pro",
    price: 399,
  },
  {
    id: "prod-4",
    title: "ScreenBar Halo Monitor Light",
    price: 189,
  },
  {
    id: "prod-5",
    title: "Anker Prime 240W GaN Station",
    price: 169,
  },
  {
    id: "prod-6",
    title: "Minimalist Wooden Desk Shelf",
    price: 149,
  },
  {
    id: "prod-7",
    title: "HHKB Professional Hybrid Type-S",
    price: 329,
  },
  {
    id: "prod-8",
    title: "Teenage Engineering OB-4 Speaker",
    price: 649,
  },
  {
    id: "prod-9",
    title: "Nomad Base One Max Dock",
    price: 149,
  },
  {
    id: "prod-10",
    title: "Govee Aura Smart Table Lamp",
    price: 69,
  }
];
