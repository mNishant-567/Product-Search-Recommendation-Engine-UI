/**
 * TypeScript Interfaces for Product Search & Dynamic Recommendation Engine
 */

export interface Product {
  id: string;
  title: string;
  category: string;
  price: number;
  rating: number;
  image: string;
  description: string;
  specs: string[];
  features: string[];
}

export interface SmartComplementary {
  title: string;
  category: string;
  estimatedPrice: number;
  description: string;
  specs: string[];
  matchReason: string;
}

export interface AIRecommendation {
  recommendationReason: string;
  suggestedCategory: string;
  smartComplementary: SmartComplementary[];
  smartTags: string[];
  matchingProductIds: string[];
}

export interface SearchState {
  query: string;
  activeCategory: string;
  isLoading: boolean;
  sortBy: "price_asc" | "price_desc" | "rating_desc" | "relevance";
}
